rm ../RDF.zip
zip -r -X ../RDF.zip . 
/usr/local/bin/aws s3 cp ../RDF.zip s3://compucom-rdf
