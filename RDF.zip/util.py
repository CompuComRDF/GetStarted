import json
import boto3
import csv
import datetime
import config
import os

def readCache(region, s3BucketName, instanceID, fileName, key):
    data={}

    os.chdir('/tmp')
    filePath = os.path.join(os.getcwd(), instanceID, fileName)
    
    if not os.path.exists(filePath):
        print("#####   CREATING CACHE: " + filePath + ' CONTACTID: ' + config.contactID  + '   #####')
        if not os.path.exists(instanceID):
            os.makedirs(instanceID)

        if 'queues.csv' == fileName:
            import queues
            import random
            import time
            connectClient = queues.connectClient(config.region, config.account)
            retry = True
            retries = 0

            while retry and retries < 3:
                print('#####   GET QUEUES ATTEMPT: ' + str(retries) + ' CONTACTID: ' + config.contactID  + '    #####')
                time.sleep(random.randint(0,5)**retries*100/1000)
                try:
                    response = connectClient.list_queues(
                        InstanceId = config.instanceID,
                        QueueTypes=[
                            'STANDARD'
                        ],
                        MaxResults=100
                    )

                    body='KEY,VALUE\n'

                    for queue in response['QueueSummaryList']:
                        body = body + queue['Name'] + ',' + queue['Id'] + '\n' 

                    with open(filePath, 'w') as queueFile:
                        queueFile.write(body)

                    retry = False
                except Exception as Ex1:
                    retries += 1
                    print('#####   GET QUEUES CSV EXCEPTION: ' + str(Ex1) + ' CONTACTID: ' + config.contactID  + '    #####')
        elif config.queueID == fileName:
            import queues
            import random
            import time
            connectClient = queues.connectClient(config.region, config.account)
            retry = True
            retries = 0
            holidayFile = config.tenantHoliday 

            while retry and retries < 3:
                print('#####   GET QUEUE ID CONFIGURATION ATTEMPT: ' + str(retries) + ' CONTACTID: ' + config.contactID  + '    #####')
                time.sleep(random.randint(0,5)**retries*100/1000)
                try:
                    queueResponse = connectClient.describe_queue(
                        InstanceId=config.instanceID,
                        QueueId=config.queueID
                    )

                    hoursResponse = connectClient.describe_hours_of_operation(
                        InstanceId=config.instanceID,
                        HoursOfOperationId=queueResponse['Queue']['HoursOfOperationId']
                    )

                    try:
                        if 'holiday' in hoursResponse['HoursOfOperation']['Description']:
                            holidayFile = hoursResponse['HoursOfOperation']['Description'] + '.csv'
                            print('#####   HOLIDAY OVERRIDE FOR QUEUE: ' + config.queueID + ' IS: ' + holidayFile + ' CONTACTID: ' + config.contactID  + '    #####')
                        else:
                            print('#####   HOLIDAY FILE FOR QUEUE: ' + config.queueID + ' IS: ' + holidayFile + ' CONTACTID: ' + config.contactID  + '    #####')
                    except:
                        print('#####   HOLIDAY FILE FOR QUEUE: ' + config.queueID + ' IS: ' + holidayFile + ' CONTACTID: ' + config.contactID  + '    #####')

                    queueDescription = ''
                    try:
                        y = queueResponse['Queue']['Description'].split()
                        for x in y:
                            if x.isupper():
                                x = ' '.join(x)
                            queueDescription += x
                            queueDescription += ' '
                    except:
                        pass

                    field_names= ['KEY', 'DESCRIPTION', 'HOURS', 'HOLIDAY', 'TIMEZONE']
                    record = [{'KEY':config.queueID, 'DESCRIPTION': queueDescription, 'HOURS': json.dumps(hoursResponse['HoursOfOperation']['Config']), 'HOLIDAY': holidayFile, 'TIMEZONE': hoursResponse['HoursOfOperation']['TimeZone']}]
                    with open(filePath, 'w') as queueFile:
                        writer = csv.DictWriter(queueFile, fieldnames=field_names)
                        writer.writeheader()
                        writer.writerows(record)

                    retry = False
                except Exception as Ex1:
                    retries += 1
                    print('#####   GET QUEUES CONFIG EXCEPTION: ' + str(Ex1) + ' CONTACTID: ' + config.contactID  + '    #####')
            
        else:
            s3Resource = boto3.resource('s3', region)
            s3Resource.meta.client.download_file(s3BucketName, "config/" + fileName, filePath)
    else:
        import time
        if 'queues.csv' not in fileName:
            s3CacheDt = datetime.datetime.strptime(time.ctime(os.path.getctime(filePath)), "%a %b %d %H:%M:%S %Y").astimezone(datetime.timezone.utc)
            client = boto3.client('s3', region)
            try:
                response = client.get_object(
                    Bucket=s3BucketName,
                    Key="config/" + fileName,
                    IfModifiedSince=s3CacheDt
                )
                print('#####   UPDATING CACHE: ' + filePath + ' CONTACTID: ' + config.contactID  + '   #####')
                s3Resource = boto3.resource('s3', region)
                s3Resource.meta.client.download_file(s3BucketName, "config/" + fileName, filePath)            
            except:
                pass

    with open(filePath, encoding="utf-8-sig") as csvfile:
        csvReader = csv.DictReader(csvfile)
        for rows in csvReader:
            record = rows[key]
            data[record] = rows     
 
    return(data)

def readCallFlowRecord(region, s3BucketName, instanceID, fileName, key, start):
    data={}

    os.chdir('/tmp')
    filePath = os.path.join(os.getcwd(), instanceID, fileName)
    
    if not os.path.exists(filePath):
        print("#####   CREATING CACHE: " + filePath + ' CONTACTID: ' + config.contactID  + '   #####')
        if not os.path.exists(instanceID):
            os.makedirs(instanceID)
        s3Resource = boto3.resource('s3', region)
        s3Resource.meta.client.download_file(s3BucketName, "config/" + fileName, filePath)
    else:
        if start:
            import time
            s3CacheDt = datetime.datetime.strptime(time.ctime(os.path.getctime(filePath)), "%a %b %d %H:%M:%S %Y").astimezone(datetime.timezone.utc)
            client = boto3.client('s3', region)
            try:
                response = client.get_object(
                    Bucket=s3BucketName,
                    Key="config/" + fileName,
                    IfModifiedSince=s3CacheDt
                )
                print('#####   UPDATING CACHE: ' + filePath + '   #####')
                s3Resource = boto3.resource('s3', region)
                s3Resource.meta.client.download_file(s3BucketName, "config/" + fileName, filePath)            
            except:
                pass

    with open(filePath, encoding="utf-8-sig") as csvfile:
        csvReader = csv.DictReader(csvfile)
        for rows in csvReader:
            record = rows[key]
            data[record] = rows     
 
    return(data)
    
def getCertificate(region, s3BucketName, instanceID, fileName):
    os.chdir('/tmp')
    filePath = os.path.join(os.getcwd(), instanceID, fileName)
    
    try:
        if not os.path.exists(filePath):
            print("#####   GETTING CERTIFICATE: " + filePath + ' CONTACTID: ' + config.contactID  + '   #####')
            if not os.path.exists(instanceID):
                os.makedirs(instanceID)
            s3Resource = boto3.resource('s3', region)
            s3Resource.meta.client.download_file(s3BucketName, "config/" + fileName, filePath)
        else:
            if start:
                import time
                s3CacheDt = datetime.datetime.strptime(time.ctime(os.path.getctime(filePath)), "%a %b %d %H:%M:%S %Y").astimezone(datetime.timezone.utc)
                client = boto3.client('s3', region)
                try:
                    response = client.get_object(
                        Bucket=s3BucketName,
                        Key="config/" + fileName,
                        IfModifiedSince=s3CacheDt
                    )
                    print('#####   UPDATING CERTIFICATE: ' + filePath + ' CONTACTID: ' + config.contactID  + '   #####')
                    s3Resource = boto3.resource('s3', region)
                    s3Resource.meta.client.download_file(s3BucketName, "config/" + fileName, filePath)            
                except:
                    pass
    except:
        pass

    return(filePath)
    
def getSysAdmin(sysAdminkey):
    sysAdminValue=''
    jsonContent = readCache(config.region, config.s3BucketName, config.instanceID, config.sysAdminFile, 'KEY')
    for j in jsonContent:
        if jsonContent[j]['KEY'] == sysAdminkey:
            sysAdminValue = jsonContent[j]['VALUE']

    if sysAdminValue=='TRUE':
        sysAdminValue=True
    if sysAdminValue=='FALSE':
        sysAdminValue=False

    return(sysAdminValue)
    
def getVoiceRecording():
    #vmail = 'audio/vmaillatency.wav'
    vmail = 'prompts/' + config.tenant + '/en-US/vmaillatency.wav'
    client = boto3.client('s3', config.region)
    try:
        response = client.list_objects_v2(
            Bucket=config.s3BucketName,
            MaxKeys=1,
            Prefix='audio/VM-' + config.contactID + '.wav',
        )
        vmail = response['Contents'][0]['Key']
        print('#####   FOUND VOICEMAIL: ' + vmail + ' CONTACTID: ' + config.contactID  + '   #####')
    except Exception as ex1:
        print(ex1)
        pass

    audio = "s3://" + config.s3BucketName + '/' + vmail 

    return(audio)

def deleteVoiceRecording(language):
    vmail = 'audio/vmaillatency.wav'
    s3TempFile = 'audio/VM-' + config.contactID + '.tmp'
    client = boto3.client('s3', config.region)
    s3Resource = boto3.resource('s3', config.region)
    print('#####   VOICE MAIL DELETION: ' + s3TempFile + '   #####')
    try:
        response = client.list_objects_v2(
            Bucket=config.s3BucketName,
            MaxKeys=1,
            Prefix='audio/VM-'+config.contactID + '.tmp',
        )
        s3TempFile = response['Contents'][0]['Key']
        s3Resource.Object(config.s3BucketName, s3TempFile).put(Body='delete')
        print('#####   VOICE MAIL MARKED FOR DELETION: ' + s3TempFile + ' CONTACTID: ' + config.contactID  + '   #####')

    except Exception as ex1:
        print('#####   VOICE MAIL DELETION EXCEPTION: ' + str(ex1) + ' CONTACTID: ' + config.contactID  + '   #####')

    try:
        response = client.list_objects_v2(
            Bucket=config.s3BucketName,
            MaxKeys=1,
            Prefix='audio/VM-'+config.contactID + '.wav',
        )
        vmail = response['Contents'][0]['Key']

        response = client.delete_object(
            Bucket=config.s3BucketName,
            Key=vmail
        )

        #Delete Voice Mail transcription
        try:
            deleteRecords('ivr-recording-contactTranscriptSegments', config.contactID, config.region)
        except Exception as ex1:
            print('#####    DELETE TRANSCRIPTION EXCEPTION: ' + str(ex1) + '    #####')

        print('#####   DELETING VOICEMAIL: ' + vmail + ' CONTACTID: ' + config.contactID  + '   #####')
        print('#####   VOICEMAIL DELETED: ' + str(response) + ' CONTACTID: ' + config.contactID  + '   #####')
        #s3Resource.Object(config.s3BucketName, s3TempFile).put(Body='cancel')
        s3Resource.Object(config.s3BucketName, s3TempFile).delete()
        
        if language == 'en-US':
            audio = 'Voice Mail Deleted'
        else:
            audio = 'Messagerie vocale supprimée'
    except:
        audio = "s3://" + config.s3BucketName + '/' + vmail 
        print('#####   VOICEMAIL NOT FOUND' + ' CONTACTID: ' + config.contactID  + '     #####')

    return(audio)

def deleteRecords(tableName, key, region):
    from boto3.dynamodb.conditions import Key

    sts_client = boto3.client('sts')
    sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::'+config.account+':role/xaccount-rdf-role',
                                      RoleSessionName='dynamodb-session')

    KEY_ID = sts_session['Credentials']['AccessKeyId']
    ACCESS_KEY = sts_session['Credentials']['SecretAccessKey']
    TOKEN = sts_session['Credentials']['SessionToken']

    #dynamodb_client = boto3.client('dynamodb',
    #    region_name=region,
    #    aws_access_key_id=KEY_ID,
    #    aws_secret_access_key=ACCESS_KEY,
    #    aws_session_token=TOKEN)

    dynamodb = boto3.resource('dynamodb',
        region_name=region,
        aws_access_key_id=KEY_ID,
        aws_secret_access_key=ACCESS_KEY,
        aws_session_token=TOKEN)

    table = dynamodb.Table(tableName)

    try:
        dynamodb_response = table.query(
            KeyConditionExpression=Key('ContactId').eq(key)
        )
        print('#####    DYNAMODB RESPONSE: ' + str(dynamodb_response) + ' CONTACTID: ' + config.contactID  + '    #####')
        print(dynamodb_response['Items'][0]['ContactId']) #Creates Exception if key doesn't exist

        items_to_delete = []
        for i in range(len(dynamodb_response['Items'])):
            item = {}
            item['ContactId']=dynamodb_response['Items'][i]['ContactId']
            item['StartTime']=dynamodb_response['Items'][i]['StartTime']
            print('item: ' + str(item))
            items_to_delete.append(item)

        print('items to delete: ' + str(items_to_delete))

        with table.batch_writer() as batch:
            for j in items_to_delete:
                response = batch.delete_item(Key={
                    "ContactId": j["ContactId"], # Change key and value names
                    "StartTime": j["StartTime"]
                })
                print('#####    DYNAMODB RESPONSE: ' + str(response) + ' CONTACTID: ' + config.contactID  + '    #####')
    except Exception as ex1:
        print('#####    DYNAMODB DELETE EXCEPTION: ' + str(ex1) + ' CONTACTID: ' + config.contactID  + '    #####')

    return()

def readDB(tableName, key, type, region, account):
    sts_client = boto3.client('sts')
    sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::'+account+':role/xaccount-rdf-role',
                                      RoleSessionName='dynamodb-session')

    KEY_ID = sts_session['Credentials']['AccessKeyId']
    ACCESS_KEY = sts_session['Credentials']['SecretAccessKey']
    TOKEN = sts_session['Credentials']['SessionToken']

    dynamodb_client = boto3.client('dynamodb',
        region_name=region,
        aws_access_key_id=KEY_ID,
        aws_secret_access_key=ACCESS_KEY,
        aws_session_token=TOKEN)

    try:
        dynamodb_response = dynamodb_client.get_item(
            TableName=tableName,
            Key={
                'Key': {'S': key}
            }
        )

        print(dynamodb_response['Item']['Key']['S']) #Creates Exception if key doesn't exist
        return(dynamodb_response['Item']['Setting'][type])

    except Exception as ex1:
        print(ex1)
        return("False")

def readCSV(region, s3BucketName, ttsFile, key):
    data = {}
    fileName = "config/" + ttsFile
    s3Resource = boto3.resource('s3', region)
    contentObject = s3Resource.Object(s3BucketName, fileName)
    fileContent = contentObject.get()['Body'].read().decode('utf-8-sig').splitlines()
    csvReader = csv.DictReader(fileContent)
    for rows in csvReader:
        record = rows[key]
        data[record] = rows

    #return(json.loads(json.dumps(data)))
    return(data)

def convert(rawData):
    dict = {}

    rawData = rawData.split("|")

    for n in range(len(rawData)):
        if rawData[n].count(':') > 1:
            dict[rawData[n][:rawData[n].find(":")]]=rawData[n][rawData[n].find(":")+1:]
        else:
            parts = rawData[n].split(":")
            dict[parts[0]]=parts[1]

    return(dict)
    
def validateJSON(jsonData):
    try:
        json.loads(jsonData)
    except ValueError as err:
        return False
    return True

def chkActionSize(rawData):
    rawData = rawData.split("|")
    if len(rawData)>1:
        return True
    return False

def addDisposition(str1, str2):
    print('#####   ' + config.tenant.upper() + ':' + str2 + ' ANI: ' + config.ani + ' CONTACTID: ' + config.contactID + '   #####')
    if not str1:
        return(str2)
    else:
        return (str1 + "," + str2)

def append(str1, str2):
    return (str1+str2)

def clearPreviousMenu(session):
    session['menuIndex'] -=1
    del session['menuTracker'][session['menuIndex']]
    if session['menuIndex'] > 0:
        session['menuIndex'] -=1
        del session['menuTracker'][session['menuIndex']]

    session['queueIndex'] -=1
    del session['queueTracker'][session['queueIndex']]
    if session['queueIndex'] > 0:
        session['queueIndex'] -=1
        del session['queueTracker'][session['queueIndex']]   

def getDynamicPrompt(promptType, menuID):
    if 'session' in menuID:
        menuPrompt = promptType + ':' + str(eval(menuID, config.rdfBuiltIns, localBuiltIns))
    else:
        menuPrompt = promptType + ':' + menuID

    dynamicMenu=''
    jsonContent = readCache(config.region, config.s3BucketName, config.instanceID, config.sysAdminFile, 'KEY')
    for j in jsonContent:
        if jsonContent[j]['KEY'] == menuID:
            dynamicMenu = convert(jsonContent[j]['VALUE'])

    for n in dynamicMenu:
        if 'x' not in n:
            menuPrompt += '|' + promptType +  ':' + menuID + '-' + n

    return(menuPrompt)

def getDynamicMenu(menuID):
    if 'session' in menuID:
        menuID = str(eval(menuID, config.rdfBuiltIns, localBuiltIns))

    dynamicMenu=''
    jsonContent = readCache(config.region, config.s3BucketName, config.instanceID, config.sysAdminFile, 'KEY')
    for j in jsonContent:
        if jsonContent[j]['KEY'] == menuID:
            dynamicMenu = jsonContent[j]['VALUE']

    return(dynamicMenu)

def checkDNIS(tableName, key):
    from boto3.dynamodb.conditions import Key, Attr
    sts_client = boto3.client('sts')
    sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::'+config.account+':role/xaccount-rdf-role',
                                      RoleSessionName='dynamodb-session')

    KEY_ID = sts_session['Credentials']['AccessKeyId']
    ACCESS_KEY = sts_session['Credentials']['SecretAccessKey']
    TOKEN = sts_session['Credentials']['SessionToken']

#    dynamodb_client = boto3.client('dynamodb',
#        region_name=config.region,
#        aws_access_key_id=KEY_ID,
#        aws_secret_access_key=ACCESS_KEY,
#        aws_session_token=TOKEN)
    dynamodb_resource = boto3.resource('dynamodb',
        region_name=config.region,
        aws_access_key_id=KEY_ID,
        aws_secret_access_key=ACCESS_KEY,
        aws_session_token=TOKEN)
    table = dynamodb_resource.Table(tableName)

    try:
        dynamodb_response = table.scan(
            #TableName=tableName,
            FilterExpression=Attr('DNIS').eq('+' + key)
        )

        print(dynamodb_response['Items'])
        companyID = dynamodb_response['Items'][0]['companyID']
        languageMenu = dynamodb_response['Items'][0]['languageMenu']
        language = dynamodb_response['Items'][0]['language']
        greeting = dynamodb_response['Items'][0]['greeting']
        companyName = dynamodb_response['Items'][0]['companyName']
        dynamicBroadcast = dynamodb_response['Items'][0]['dynamicBroadcast']
        
        return {
                'companyID': companyID,
                'languageMenu': languageMenu,
                'language': language,
                'greeting': greeting,
                'companyName': companyName,
                'dynamicBroadcast': dynamicBroadcast
            }
                
    except Exception as ex1:
        print('#####    CHECK DNIS EXCEPTION: ' + str(ex1) + ' CONTACTID: ' + config.contactID  + '    #####')
        return("False")

